//
//  dSpider.h
//  spider
//
//  Created by 杜文 on 17/3/27.
//  Copyright © 2017年 杜文. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DSpiderViewController.h"

int  DSPIDER_APP_ID=0;
@interface dSpider : NSObject
 + (void)init:(int) appid;
@end
